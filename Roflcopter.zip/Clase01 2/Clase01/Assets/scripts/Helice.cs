﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Helice : MonoBehaviour {
	public float angle;
	float smooth = 9000.0f;
    float tiltAngle = 600.0f;
	private float timeCount = 0.0f;
	float x = 0;
	
	// Use this for initialization
	void Start () {
		//angle = 0f;
	}
	
	// Update is called once per frame
	void Update () {
      /*
	    float tiltAroundX = Input.GetAxis("Horizontal") * tiltAngle;
        // Rotate the cube by converting the angles into a quaternion.
        Quaternion target = Quaternion.Euler(0 , (tiltAroundX*timeCount), 0);
		        // Dampen towards the target rotation
        gameObject.transform.GetChild(0).transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * smooth);
		timeCount = timeCount + Time.deltaTime;
		*/
		if(Input.GetKey(KeyCode.E)){
			transform.Rotate(new Vector3 (0f,x,0f)*Time.deltaTime);
			if(x<2000){
				x=x+20;
				}
			}
			if (x>0){
				x=x-10;
				transform.Rotate(new Vector3 (0f,x,0f)*Time.deltaTime);
				}
				
				
		
	}
}