﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour {

	// Use this for initialization
	public float speed;
	public float Gravity;
	private float xAxis, zAxis,yAxis;
	void Start () {
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {


		bool Encendido;
		//int contador =0 ;
		//for (n = 0; n < 100; n++) {
		/*
		if (Input.GetKey (KeyCode.LeftShift)) {
			Encendido = false;
*/


		
			//Debug.Log (contador);

		
			//if (Encendido != true) {
			
				if (Input.GetKey (KeyCode.W)) {
					transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					//transform.Rotate (new Vector3 (-10f, 0f, 0f) * Time.deltaTime);
				}
				if (Input.GetKey (KeyCode.S)) {
					transform.Translate (new Vector3 (25, 0, speed) * Time.deltaTime);
					//transform.Rotate (new Vector3 (10f, 0f, 0f) * Time.deltaTime);

				}
				if (Input.GetKey (KeyCode.A)) {
					transform.Translate (new Vector3 (speed, 0, -25) * Time.deltaTime);
					//transform.Rotate (new Vector3 (0f, 0f, -10f) * Time.deltaTime);
					//transform.Rotate (new Vector3 (20f, 0f, 0f) * Time.deltaTime);
				}
				if (Input.GetKey (KeyCode.D)) {
					transform.Translate (new Vector3 (-speed, 0, 25) * Time.deltaTime);
					//transform.Rotate (new Vector3 (0f, 0f, 10f) * Time.deltaTime);
					//transform.Rotate (new Vector3 (20f, 0f, 0f) * Time.deltaTime);
				}
				if (Input.GetKey (KeyCode.Space)) {
					transform.Translate (new Vector3 (0, Gravity*2, 0) * Time.deltaTime);
				}

			//}
		//}
		//}
		
	}
	void OnCollisionEnter( Collision collision){
		Debug.Log (collision.gameObject.name);

	}

}
