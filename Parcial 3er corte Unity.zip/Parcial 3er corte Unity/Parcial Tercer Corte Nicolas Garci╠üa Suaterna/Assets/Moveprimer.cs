﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moveprimer : MonoBehaviour {

	// Use this for initialization
	public float speed;
	public float Gravity;
	private float xAxis, zAxis,yAxis;
	
	public float mov;
	public bool encendido = false;
	void Start () {
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {


		
		//int contador =0 ;
		//for (n = 0; n < 100; n++) {
		/*
		if (Input.GetKey (KeyCode.LeftShift)) {
			Encendido = false;
*/


		
			//Debug.Log (contador);

		
			//if (Encendido != true) {
			
				if (Input.GetKey (KeyCode.W)) {
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					
					if(encendido==false){
					if (mov<100f){
					transform.Rotate (new Vector3 (0f, -mov, 0f) * Time.deltaTime);
					mov=mov+1f;
						
					}
					}
					
					if (mov==100f){
					encendido=true;	
					}
					
					if(encendido==true){
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					transform.Rotate (new Vector3 (0f, mov, 0f) * Time.deltaTime);
					mov=mov-1f;
						
						if(mov==0){encendido=false;}
					}
					
					
				}
		
		
				if (Input.GetKey (KeyCode.S)) {
					//transform.Translate (new Vector3 (25, 0, speed) * Time.deltaTime);
					if(encendido==false){
					if (mov<100f){
					transform.Rotate (new Vector3 (0f, -mov, 0f) * Time.deltaTime);
					mov=mov+1f;
						
					}
					}
					if (mov==100f){
					encendido=true;	
					}
					
					if(encendido==true){
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					transform.Rotate (new Vector3 (0f, mov, 0f) * Time.deltaTime);
					mov=mov-1f;
						if(mov==0){encendido=false;}
					}
					
					

				}
				if (Input.GetKey (KeyCode.A)) {
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					
					if(encendido==false){
					if (mov<100f){
					transform.Rotate (new Vector3 (0f, -mov, 0f) * Time.deltaTime);
					mov=mov+1f;
						
					}
					}
					
					if (mov==100f){
					encendido=true;	
					}
					
					if(encendido==true){
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					transform.Rotate (new Vector3 (0f, mov, 0f) * Time.deltaTime);
					mov=mov-1f;
						
						if(mov==0){encendido=false;}
					}
					
				}
				if (Input.GetKey (KeyCode.D)) {
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					
					if(encendido==false){
					if (mov<100f){
					transform.Rotate (new Vector3 (0f, -mov, 0f) * Time.deltaTime);
					mov=mov+1f;
						
					}
					}
					
					if (mov==100f){
					encendido=true;	
					}
					
					if(encendido==true){
					//transform.Translate (new Vector3 (-25, 0, -speed) * Time.deltaTime);
					transform.Rotate (new Vector3 (0f, mov, 0f) * Time.deltaTime);
					mov=mov-1f;
						
						if(mov==0){encendido=false;}
					}
					
				}
				

			//}
		//}
		//}
		
	}
	void OnCollisionEnter( Collision collision){
		Debug.Log (collision.gameObject.name);
	}
}
